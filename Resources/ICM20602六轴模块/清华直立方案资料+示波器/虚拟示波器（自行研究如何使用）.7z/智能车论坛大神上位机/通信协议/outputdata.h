#ifndef _outputdata_H
#define _outputdata_H
extern void OutPut_Data(int x,int y,int z,int w);
#endif 
