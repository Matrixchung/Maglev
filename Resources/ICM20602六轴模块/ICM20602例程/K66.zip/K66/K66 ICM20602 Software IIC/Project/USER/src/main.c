/*********************************************************************************************************************
 * COPYRIGHT NOTICE
 * Copyright (c) 2018,逐飞科技
 * All rights reserved.
 * 技术讨论QQ群：一群：179029047(已满)  二群：244861897(已满)  三群：824575535
 *
 * 以下所有内容版权均属逐飞科技所有，未经允许不得用于商业用途，
 * 欢迎各位使用并传播本程序，修改内容时必须保留逐飞科技的版权声明。
 *
 * @file       		main
 * @company	   		成都逐飞科技有限公司
 * @author     		逐飞科技(QQ3184284598)
 * @version    		查看doc内version文件 版本说明
 * @Software 		IAR 8.3 or MDK 5.24
 * @Taobao   		https://seekfree.taobao.com/
 * @date       		2019-11-08
 * @note		
					接线定义：
					------------------------------------ 
					模块管脚			单片机管脚
					SCL					查看SEEKFREE_IIC.h文件中的SEEKFREE_SCL 宏定义
					SDA					查看SEEKFREE_IIC.h文件中的SEEKFREE_SCL 宏定义
					VCC					3.3V
					GND					GND
					------------------------------------ 
 ********************************************************************************************************************/


#include "headfile.h"


//在线调试查看如下变量即可，得到陀螺仪和加速度计数据
//icm_gyro_x,icm_gyro_y,icm_gyro_z;
//icm_acc_x,icm_acc_y,icm_acc_z;

int main(void)
{
	get_clk();//上电后必须运行一次这个函数，获取各个频率信息，便于后面各个模块的参数设置
	
    //本例程仅仅使用模拟IIC进行数据采集
    
	IIC_init();         //模拟IIC 初始化
    icm20602_init();    //六轴陀螺仪初始化
    
    for(;;)
	{
		get_icm20602_accdata(); //获取加速度数据
        get_icm20602_gyro();    //获取陀螺仪数据
        
	}

}
