/*********************************************************************************************************************
 * COPYRIGHT NOTICE
 * Copyright (c) 2018,逐飞科技
 * All rights reserved.
 * 技术讨论QQ群：一群：179029047(已满)  二群：244861897(已满)  三群：824575535
 *
 * 以下所有内容版权均属逐飞科技所有，未经允许不得用于商业用途，
 * 欢迎各位使用并传播本程序，修改内容时必须保留逐飞科技的版权声明。
 *
 * @file       		main
 * @company	   		成都逐飞科技有限公司
 * @author     		逐飞科技(QQ3184284598)
 * @version    		查看doc内version文件 版本说明
 * @Software 		IAR 8.3 or MDK 5.24
 * @Taobao   		https://seekfree.taobao.com/
 * @date       		2019-11-08
 * @note		
					接线定义：
					------------------------------------ 
					模块管脚			单片机管脚
					SCL					查看SEEKFREE_ICM20602.c文件中的IIC_SCL_PIN 宏定义
					SDA					查看SEEKFREE_ICM20602.c文件中的IIC_SDA_PIN 宏定义
					VCC					3.3V
					GND					GND
					------------------------------------ 
 ********************************************************************************************************************/



//打开新的工程或者工程移动了位置务必执行以下操作
//第一步 关闭上面所有打开的文件
//第二步 project  clean  等待下方进度条走完


//在线调试查看如下变量即可，得到陀螺仪和加速度计数据
//icm_gyro_x,icm_gyro_y,icm_gyro_z;
//icm_acc_x,icm_acc_y,icm_acc_z;
		
#include "headfile.h"

int main(void)
{   
    get_clk();

    //本例程仅仅使用硬件IIC进行数据采集
    
    icm20602_init_hardware();      //硬件IIC_5 初始化
    EnableInterrupts;

    while(1)
    {
        get_icm20602_accdata_hardware(); //获取加速度数据
        get_icm20602_gyro_hardware();    //获取陀螺仪数据
    }
}


