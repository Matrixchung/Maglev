#ifndef _SEEKFREE_VIRSCO_H
#define _SEEKFREE_VIRSCO_H


extern uint8 outdata[10];

void OutPut_Data(int16 data1, int16 data2, int16 data3, int16 data4, uint8 *dat);


#endif 
