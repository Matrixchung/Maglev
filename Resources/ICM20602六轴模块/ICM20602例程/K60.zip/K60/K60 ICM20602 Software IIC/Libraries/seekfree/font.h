#ifndef _font_h
#define _font_h

#include "common.h"


extern const uint8 tft_ascii[95][16];
extern const uint8  asc2_1608[1520];
#endif
